/*
    오라클 계정 생성 문법
    - CREATE USER 계정명 IDENTIFIED BY 비밀번호;
    - 오라클에서 사용자계정을 만들 수 있는 권한은 관리자 계정에게만 존재
    */
CREATE USER KH IDENTIFIED BY KH;